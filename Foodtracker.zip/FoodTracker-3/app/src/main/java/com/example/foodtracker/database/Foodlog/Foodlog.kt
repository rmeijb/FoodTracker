package com.example.foodtracker.database.Foodlog

enum class Type {
    Consume, Complaint, Ontlasting, Period
}
class Foodlog(val id: Int = 0, val item: String, val type: Type, val date: String )