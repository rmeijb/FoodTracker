package com.example.foodtracker.database.Foodlog

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

//class Foodlog(val id: Int = 0, val item: String, val type: Type, val date: String )

@Dao
interface FoodlogDao {
    @Query("SELECT id, product_name as item, 'Consume' as type, datetime as date FROM consume UNION SELECT id, symptom as item, 'Complaint' as type, start_datetime as date FROM complaint UNION SELECT id, 'Menstruatie' as item, 'Period' as type, start_datetime as date FROM period UNION SELECT id, type as item, 'Ontlasting' as type, start_datetime as date FROM ontlasting ORDER BY date")
    fun getAll(): Flow<List<Foodlog>>
}