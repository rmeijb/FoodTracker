package com.example.foodtracker.database.symptom

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//@Entity(tableName = "symptom")
//data class Symptom(
//    @PrimaryKey(autoGenerate = true) val id: Int,
//    @NonNull @ColumnInfo(name = "symptom") val category: String
//)