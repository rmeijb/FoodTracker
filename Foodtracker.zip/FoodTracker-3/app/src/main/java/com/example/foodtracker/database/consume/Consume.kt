package com.example.foodtracker.database.consume

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "consume")
data class Consume(
    @PrimaryKey(autoGenerate = true) var id: Int,
    @NonNull @ColumnInfo(name = "product_id") var productId: Int,
    @NonNull @ColumnInfo(name = "product_name") val productName: String,
    @NonNull @ColumnInfo(name = "datetime") var datetime: String,
    @NonNull @ColumnInfo(name = "unit", defaultValue = "stuks") var unit: String,
    @NonNull @ColumnInfo(name = "quantity") var quantity: Double
) : java.io.Serializable
