package com.example.foodtracker

import com.example.foodtracker.database.consume.Consume
import com.example.foodtracker.database.consume.ConsumeDao

class ConsumeRepository(private val dao: ConsumeDao) {

    val consumes = dao.getAll()

    suspend fun insert(consume: Consume) {
        return dao.insertConsume(consume)
    }

    suspend fun update(consume: Consume) {
        return dao.updateConsume(consume)
    }

//    suspend fun delete(subscriber: Subscriber): Int {
//        return dao.deleteSubscriber(subscriber)
//    }
//
//    suspend fun deleteAll(): Int {
//        return dao.deleteAll()
//    }
}
