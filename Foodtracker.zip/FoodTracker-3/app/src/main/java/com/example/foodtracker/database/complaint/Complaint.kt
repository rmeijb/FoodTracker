package com.example.foodtracker.database.complaint

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "complaint")
data class Complaint(
    @PrimaryKey(autoGenerate = true) val id: Int,
    @NonNull @ColumnInfo(name = "symptom") var symptom: String,
    @NonNull @ColumnInfo(name = "start_datetime") var startdatetime: String,
    @ColumnInfo(name = "end_datetime") var enddatetime: String,
    @NonNull @ColumnInfo(name = "severeness") var severeness: Int,
    @ColumnInfo(name = "description") var description: String
): java.io.Serializable