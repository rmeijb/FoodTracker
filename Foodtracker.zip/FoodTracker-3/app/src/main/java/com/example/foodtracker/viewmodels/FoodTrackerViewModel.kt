package com.example.foodtracker.viewmodels

import androidx.lifecycle.ViewModel

class FoodTrackerViewModel(): ViewModel() {

    // TODO: Implement the ViewModel
}