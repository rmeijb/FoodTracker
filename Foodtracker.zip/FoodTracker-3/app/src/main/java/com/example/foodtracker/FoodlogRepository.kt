package com.example.foodtracker

import com.example.foodtracker.database.Foodlog.Foodlog
import com.example.foodtracker.database.Foodlog.FoodlogDao
import kotlinx.coroutines.flow.*

class FoodlogRepository(private val foodlogDao: FoodlogDao, ) {

    //val consumes = consumeDao.getAll()
    //val complaints = complaintDao.getAll()
    val foodtrack = foodlogDao.getAll()

//    fun getAll(): Flow<List<Foodlog>> {
//        val foodlogs:Flow<List<Foodlog>> = flow {
//            foodtrack.collect() {
//                val consumeList = ArrayList<Foodlog>()
//                it.forEach() {
//                    val foodlog = Foodlog(0, it.productName, Type.Consume, it.datetime)
//                    consumeList.add(foodlog)
//                }
//                emit(consumeList)
//            }
//        }
//        val foodlogs2:Flow<List<Foodlog>> = flow {
//            complaints.collect() {
//                val complaintList = ArrayList<Foodlog>()
//                it.forEach() {
//                   val foodlog = Foodlog(0,it.symptom, Type.Complaint, it.startdatetime )
//                   complaintList.add(foodlog)
//                }
//                emit(complaintList)
//            }
//        }
//        return merge(foodlogs, foodlogs2)
//        return foodlogs
//    }


    fun Flow<List<Any>>.skipOddAndDuplicateEven(): Flow<List<Foodlog>> = transform { value ->
        //if (value  == 0) { // Emit only even values, but twice
          //  emit(value)
            //emit(value)
        //} // Do nothing if odd
    }
}
