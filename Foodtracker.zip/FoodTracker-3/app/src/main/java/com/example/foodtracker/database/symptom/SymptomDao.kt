package com.example.foodtracker.database.symptom

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

//@Dao
//interface SymptomDao {
//    @Query("SELECT * FROM symptom ORDER BY id")
//    fun getAll(): Flow<List<Symptom>>
//}